#include "stm32f10x.h"
#include "stm32f10x_exti.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_usart.h"
#include "stm32f10x_rcc.h"
#include "DHT11.h"
#include "misc.h"

#define DHT11_DATA_GPIO_Port    GPIOA
#define DHT11_DATA_Pin          GPIO_Pin_14
DHT11DATA dht11_data;

/* function prototype */
void RCC_Configure(void);
void GPIO_Configure(void);
void EXTI_Configure(void);
void Init_USART(void);
void NVIC_Configure(void);

void EXTI15_10_IRQHandler(void);

void Delay(void);

void sendDataUART1(uint16_t data);
void sendDataUART2(uint16_t data);

void Delay_us(uint32_t us){  
                if(us>1){
                         uint32_t count=us*7200;
                         while(count--); 
                 }else{
                         uint32_t count=2;
                         while(count--); 
                  }
}

uint8_t DHT11ReadData(DHT11DATA *pData)
{
    uint32_t tmp;
    uint32_t i;
    uint16_t data[DHT11_DATA_BITS] = {0,};
 
    pData->humid = pData->temp = pData->checksum = 0;
    // set DHT11_DATA Pin for output
    tmp = DHT11_DATA_GPIO_Port->CRH;
    tmp &= 0x0FFFFFFF;
    tmp |= 0x20000000;
    DHT11_DATA_GPIO_Port->CRH = tmp;
 
    // transmit start signal
    DHT11_DATA_GPIO_Port->BSRR = DHT11_DATA_Pin;
    Delay_us(250);
    DHT11_DATA_GPIO_Port->BRR = DHT11_DATA_Pin;
    Delay_us(1);
    DHT11_DATA_GPIO_Port->BSRR = DHT11_DATA_Pin;
 
    // set DHT11_DATA Pin for  pull-up input
    tmp = DHT11_DATA_GPIO_Port->CRH;
    DHT11_DATA_GPIO_Port->ODR = DHT11_DATA_Pin;
    tmp &= 0x0FFFFFFF;
    tmp |= 0x80000000;
    DHT11_DATA_GPIO_Port->CRH = tmp;
 
    // wait for DHT11's reply
    if(WaitForLow(DHT11_MAX_REPLY_TIME) > DHT11_MAX_REPLY_TIME)
        return DHT11_NOT_REPLY;
 
    // DHT11's low signal
    if(WaitForHigh(DHT11_SIGNAL_LENGTH) > DHT11_SIGNAL_LENGTH)
        return DHT11_SIGNAL_ERR;
 
    // wait for data
    if(WaitForLow(DHT11_SIGNAL_LENGTH) > DHT11_SIGNAL_LENGTH)
        return DHT11_DATA_NOT_START;
 
    // put 40 wait repeat times to array data[]
    for(i = 0;i < DHT11_DATA_BITS;i++)
    {
        WaitForHigh(DHT11_DATA_LOW_LENGTH);
        data[i] = WaitForLow(DHT11_DATA_HIGH_LENGTH_1);
        if(data[i] > DHT11_DATA_HIGH_LENGTH_1)                 // error occurred
            return (DHT11_DATA_HIGH_ERR + i);
    }
 
    // calculate humidity
    for(i = 0;i < 16;i++)
    {
        if(i > 0) pData->humid <<= 1;
        if(data[i] > DHT11_DATA_HIGH_LENGTH_0)
            pData->humid |= 1;
    }
 
    // calculate temp
    for(;i < 32;i++)
    {
        if(i > 16) pData->temp <<= 1;
        if(data[i] > DHT11_DATA_HIGH_LENGTH_0)
            pData->temp |= 1;
    }
 
    // calculate checksum
    for(;i < DHT11_DATA_BITS;i++)
    {
        if(i > 32) pData->checksum <<= 1;
        if(data[i] > DHT11_DATA_HIGH_LENGTH_0)
            pData->checksum |= 1;
    }
 
    // check checksum
    if(pData->checksum != (pData->humid / 256 + pData->humid % 256 + pData->temp / 256 + pData->temp % 256) % 256)
        return DHT11_CHKSUM_ERR;
    return DHT11_SUCCESS;
}
 
uint32_t WaitForLow(uint32_t max)
{
    uint32_t time = 0;
    while((DHT11_DATA_GPIO_Port->IDR & DHT11_DATA_Pin) && (time++ < max));
    return time;
}
 
uint32_t WaitForHigh(uint32_t max)
{
    uint32_t time = 0;
    while(!(DHT11_DATA_GPIO_Port->IDR & DHT11_DATA_Pin) && (time++ < max));
    return time;
}

void RCC_Configure(void)
{
    /* UART TX/RX port clock enable */ // PA9, PA10
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    /* USART1 clock enable */ //
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
    /* USART2 clock enable */ //
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);

    /* Alternate Function IO clock enable */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
}

void GPIO_Configure(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    /* UART1 pin setting */
    //TX
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
   
    //RX
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    //TEMP
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    /* UART2 pin setting */
    //TX
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
   
    //RX
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

}

void EXTI_Configure(void)
{
    EXTI_InitTypeDef EXTI_InitStructure;

    /* USART1: RX*/
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource10);
    EXTI_InitStructure.EXTI_Line = EXTI_Line10;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

    /* USART2: RX*/
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource3);
    EXTI_InitStructure.EXTI_Line = EXTI_Line3;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);
}

void Init_USART(void)
{
    USART_InitTypeDef USART1_InitStructure;
    USART_InitTypeDef USART2_InitStructure;

    // Enable the USART1, 2 peripheral
    USART_Cmd(USART1, ENABLE);
    USART_Cmd(USART2, ENABLE);
    
    USART1_InitStructure.USART_BaudRate = 9600;
    USART1_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART1_InitStructure.USART_StopBits = USART_StopBits_1;
    USART1_InitStructure.USART_Parity = USART_Parity_No;
    USART1_InitStructure.USART_Mode = (USART_CR1_RE | USART_CR1_TE | USART_CR1_UE);
    USART1_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_Init(USART1, &USART1_InitStructure);

    USART2_InitStructure.USART_BaudRate = 9600;
    USART2_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART2_InitStructure.USART_StopBits = USART_StopBits_1;
    USART2_InitStructure.USART_Parity = USART_Parity_No;
    USART2_InitStructure.USART_Mode = (USART_CR1_RE | USART_CR1_TE | USART_CR1_UE);
    USART2_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_Init(USART2, &USART2_InitStructure);
    
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
}


void NVIC_Configure(void) {

    NVIC_InitTypeDef NVIC_InitStructure;
    
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);

    // UART1
    // 'NVIC_EnableIRQ' is only required for USART setting
    NVIC_EnableIRQ(USART1_IRQn);
    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = NVIC_IPR0_PRI_0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    // UART2
    // 'NVIC_EnableIRQ' is only required for USART setting
    NVIC_EnableIRQ(USART2_IRQn);
    NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = NVIC_IPR0_PRI_0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

void USART1_IRQHandler() {      // board --> app
    uint16_t word;
    if(USART_GetITStatus(USART1,USART_IT_RXNE)!=RESET){
        // the most recent received data by the USART1 peripheral
        word = USART_ReceiveData(USART1);

     
        sendDataUART2(word);

        // clear 'Read data register not empty' flag
        USART_ClearITPendingBit(USART1,USART_IT_RXNE);
    }
}

// TODO!!!: USART2 handler
void USART2_IRQHandler() {      // app -> board

    uint16_t word;
    if(USART_GetITStatus(USART2,USART_IT_RXNE)!=RESET){
        // the most recent received data by the USART1 peripheral
        word = USART_ReceiveData(USART2);

        sendDataUART1(word);
        // clear 'Read data register not empty' flag
        USART_ClearITPendingBit(USART2,USART_IT_RXNE);
    }
}


void sendTempHumedity(){
  
}

void sendLight(){
  
}

void sendDataUART1(uint16_t data) {
    
    USART_SendData(USART1, data);
}

void sendDataUART2(uint16_t data) {
    
    USART_SendData(USART2, data);
}


int main(void)
{

    SystemInit();

    RCC_Configure();

    GPIO_Configure();

    //EXTI_Configure();

    Init_USART();

    NVIC_Configure();

    while (1){
      sendDataUART1('A');
      int ret = DHT11ReadData(&dht11_data);
      //char buf[16];
      //sprintf(buf, "%d %d", dht11_data.humid, dht11_data.temp);
      
      //for(int i = 0; buf[i] != '\0'; i++){
        sendDataUART1(((char*)dht11_data.humid)[0]);
        sendDataUART1(((char*)dht11_data.humid)[1]);
        sendDataUART1(((char*)dht11_data.temp)[0]);
        sendDataUART1(((char*)dht11_data.temp)[1]);
      //}
      Delay_us(1000);
    }
}
